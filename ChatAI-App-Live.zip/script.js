document.addEventListener("DOMContentLoaded", function() {
  async function getAIResponse(userMessage) {
    userMessage = userMessage.toLowerCase();
    
    // Check for simple predefined answers first
    const responses = {
      "hello": "Hello! How can I assist you today?",
      "how are you": "I'm just a bot, but I'm doing great! How about you?",
      "what is your name": "I'm ChatAI, your virtual assistant!",
      "what can you do": "I can chat with you and answer questions using real-time data.",
      "who created you": "I was created by a developer like you!",
      "bye": "Goodbye! Have a great day!"
    };

    if (responses[userMessage]) {
      return responses[userMessage];
    }

    // Fetch live data from the internet
    try {
      const response = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(userMessage)}&format=json`);
      const data = await response.json();

      if (data.AbstractText) {
        return data.AbstractText;
      } else {
        return "I'm not sure, but you can check more details on Google!";
      }
    } catch (error) {
      return "I couldn't fetch the answer right now. Please try again later.";
    }
  }

  function addMessageToChatBox(message, isUser) {
    const chatBox = document.getElementById("chat-box");
    const messageElement = document.createElement("div");
    messageElement.classList.add(isUser ? "user-message" : "ai-message");
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  document.getElementById("send-btn").addEventListener("click", async function() {
    const userInput = document.getElementById("user-input");
    const userMessage = userInput.value.trim();

    if (userMessage) {
      addMessageToChatBox(userMessage, true);
      userInput.value = "";

      setTimeout(async () => {
        const aiResponse = await getAIResponse(userMessage);
        addMessageToChatBox(aiResponse, false);
      }, 500);
    }
  });

  document.getElementById("user-input").addEventListener("keypress", function(e) {
    if (e.key === "Enter") {
      document.getElementById("send-btn").click();
    }
  });
});
